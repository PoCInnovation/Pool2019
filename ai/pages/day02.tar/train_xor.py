import numpy as np
from NeuralNetwork import NeuralNetwork
from cross_entropy import calculate_cross_entropy

ENTRIES = np.array([[0.0, 0.0], \
                    [0.0, 1.0], \
                    [1.0, 0.0], \
                    [1.0, 1.0]])

OUTS = np.array([[1.0, 0.0], \
                 [0.0, 1.0], \
                 [0.0, 1.0], \
                 [1.0, 0.0]])

MU = 0.01

LEARNING_RATE = 1

if __name__ == "__main__":
    nn = NeuralNetwork(2, [2, 2])
    loss = 1.0
    i = 0

    while loss >= MU:
        predictions = nn.activate(ENTRIES)
        if i % 10 == 0:
            loss = calculate_cross_entropy(ENTRIES, predictions, OUTS)
            print("Epoch %d: Loss = %f" % (i, loss))
        grad = nn.calculate_gradient(ENTRIES, OUTS)
        nn.apply_gradient(grad, LEARNING_RATE)
        i += 1

    print("Testing:")
    print(nn.activate(ENTRIES))
