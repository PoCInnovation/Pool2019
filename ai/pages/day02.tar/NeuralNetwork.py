import numpy as np
from Neuron import Neuron

class NeuralNetwork:
    def __init__(self, nbEntry, neuronPerLayer, min=-1.0, max=1.0, weights=None):
        self.layers = []

        # Construct layers randomly if weights is None, initialize with given weights otherwise.
        if weights is None:
            for nbNeuron in neuronPerLayer:
                layer = [Neuron(nbEntry if len(self.layers) == 0 else len(self.layers[-1]), \
                                min, max) for _ in range(nbNeuron)]
                self.layers.append(layer)
        else:
            for i in range(len(weights)):
                layer = [Neuron(nbEntry if len(self.layers) == 0 else len(self.layers[-1]), \
                                min, max, weights[i][j]) \
                         for j in range(len(weights[i]))]
                self.layers.append(layer)

    # Activate the neural network with given entries and return the last layer activation
    # Entries is a 2D numpy array
    def activate(self, entries):
        # <====== To complete | Exercice 9 ======>
        return np.zeros([len(entires), len(self.layers[-1])])

    # Return an activation array of all neurons in the network.
    # Entries is concidered as a layer, so,
    # it must be at the first position in the returned array.
    # This function allow you to have entries and activations of each layer
    # for the backpropagation process.
    def get_all_entries(self, entries):
        all_entries = [entries]
        # <====== To complete | Exercice 10 ======>
        return all_entries

    # Calculate gradient of the output layer.
    # Each position in the returned array is the result of the calculate_gradient_out
    # function of each output neuron.
    # layer_entries is the entry matrix of the layer
    # activations is the prediction matrix of the layer
    # expected_outputs is the output matrix expected for the entry matrix
    def calculate_output_layer_gradient(self, layer_entries, activations, expected_outputs):
        out = []
        # <====== To complete | Exercice 10 ======>
        return np.array(out)

    # Calculate gradient of an hidden layer.
    # Each position in the returned array is the result of the calculate_gradient_hidden
    # function of each neuron in the given layer.
    # layer_idx is the index of the computed layer
    # layer_entries is the entry matrix of the layer
    # activations is the prediction matrix of the layer
    # next_layer_gradient is the computed gradient of the next layer
    def calculate_hidden_layer_gradient(self, layer_idx, layer_entries, \
                                        activations, next_layer_gradient):
        out = []
        # <====== To complete | Exercice 10 ======>
        return np.array(out)

    # Calculate the gradient of the neural network
    # Execute a forward activation (_get_all_entries) and backpropagate the gradient
    def calculate_gradient(self, entries, expected_outs):
        all_entries = self.get_all_entries(entries)
        gradient = []

        for layer_idx in reversed(range(len(self.layers))):
            if layer_idx == len(self.layers) - 1:
                gradient.insert(0, self.calculate_output_layer_gradient\
                                (all_entries[layer_idx], all_entries[layer_idx + 1], \
                                 expected_outs))
            else:
                gradient.insert(0, self.calculate_hidden_layer_gradient\
                                (layer_idx, all_entries[layer_idx], all_entries[layer_idx + 1], \
                                 gradient[-1]))

        return gradient

    # Apply given gradient on the neural network with a given learning_rate
    def apply_gradient(self, gradient, learning_rate):
        for layer_idx in range(len(self.layers)):
            for neuron_idx in range(len(self.layers[layer_idx])):
                self.layers[layer_idx][neuron_idx].apply_gradient\
                    (gradient[layer_idx][neuron_idx], learning_rate)

if __name__ == "__main__":
    weights = [[np.array([[-2.2, 1.7, -0.92]]), np.array([[0.45, 1.0, 0.001]])], # Hidden layer weights \
               [np.array([[1.2, -0.3, 1.41111]]), np.array([[-1.2, 0.3, -1.41111]])]] # Output layer weights
    nn = NeuralNetwork(2, [2, 2], weights=weights)

    entries = np.array([[1.0, -0.283], \
                        [-2.42, -2.42], \
                        [4.3, 0.1]])
    print(nn.activate(entries))
