import numpy as np
from Neuron import Neuron
from cross_entropy import calculate_cross_entropy

ENTRIES = np.array([[0.0, 0.0], \
                    [0.0, 1.0], \
                    [1.0, 0.0], \
                    [1.0, 1.0]])

OUTS = np.array([[0.0], \
                 [1.0], \
                 [1.0], \
                 [1.0]])

LEARNING_RATE = 0.1

if __name__ == "__main__":
    neuron = Neuron(2)

    for i in range(1000):
        predictions = neuron.activate(ENTRIES)
        if i % 10 == 0:
            print("Epoch %d: Loss = %f" % (i, calculate_cross_entropy(ENTRIES, predictions, OUTS)))
        grad = neuron.calculate_gradient_out(ENTRIES, predictions, OUTS)
        neuron.apply_gradient(grad, LEARNING_RATE)

    print("Testing:")
    print(neuron.activate(ENTRIES))
