import numpy as np

# Cumpute sigmoid function
def sigmoid(x):
    return x # <====== To complete | Exercice 3 ======>

class Neuron:
    def __init__(self, nbEntry, min=-1.0, max=1.0, weights=None):
        # Initialize neuron randomly if weights is None, with given weights otherwise.
        if weights is None:
            self.weights = np.random.uniform(min, max, [1, nbEntry + 1]) # nbEntry + 1 for the bias
        else:
            self.weights = weights

    # Add ones column at the end of each entry for bias activation
    def _add_ones_to_entries(self, entries):
        return np.concatenate([entries, np.ones([entries.shape[0], 1])], axis=1)

    # Activate neuron with given entries
    # entries is a 2D numpy array, with n rows, and nbEntry columns
    def activate(self, entries):
        # Add ones column at the end of the entries matrix for bias
        entries = self._add_ones_to_entries(entries)

        # <====== To complete | Exercice 3 ======>
        return 0.0

    # Calculate gradient for output neuron
    # entries is a 2D numpy array, with n rows, and nbEntry columns
    # predictions is a 2D numpy array, with n rows, and 1 out, given by a call
    # of the activate function
    # expected_outs is a 2D numpy array, with n rows, and 1 out
    def calculate_gradient_out(self, entries, predictions, expected_outs):
        # Add ones column at the end of the entries matrix for bias
        entries = self._add_ones_to_entries(entries)

        # <====== To complete | Exercice 4 ======>
        return np.zeros(self.weights.shape)

    # Calculate gradient for hidden neuron
    # entries is a 2D numpy array, with n rows, and nbEntry columns
    # predictions is a 2D numpy array, with n rows, and 1 out, given by a call
    # of the activate function
    # next_layer a list of neurons objects that correspond to the next layer
    # in the neural network. It allow you to access to all weights linked
    # to the output of the neuron
    # next_layer_gradient is the list of calculated derivative of the next layer
    # neuron_idx is the index of the current neuron in the layer
    def calculate_gradient_hidden(self, entries, predictions, next_layer,
                                  next_layer_gradient, neuron_idx):
        # Add ones column at the end of the entries matrix for bias
        entries = self._add_ones_to_entries(entries)

        # <====== To complete | Exercice 10 ======>
        return np.zeros(self.weights.shape)

    # Mean gradient and apply it on weights.
    # grad is a numpy array with the same shape than self.weights
    # learning_rate is a scalar
    def apply_gradient(self, grad, learning_rate):
        # <====== To complete | Exercice 4 ======>
        self.weights = np.zeros(self.weights.shape)

# Test main for exercice 3
if __name__ == "__main__":
    weights = np.array([[3.14, -1.42, 2.84]])

    neuron = Neuron(2, weights=weights)
    entries = np.array([[0.0, 0.0], \
                        [-2.5, 1.5], \
                        [0.36, -1.92]])

    print(neuron.activate(entries))
