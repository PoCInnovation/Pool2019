import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from Neuron import Neuron

def visualize_activation(neuron):
    x = np.arange(-30, 30, 3.)
    y = np.arange(-30, 30, 3.)
    x, y = np.meshgrid(x, y)
    x_exp = np.expand_dims(x, axis=2)
    y_exp = np.expand_dims(y, axis=2)
    entry = np.concatenate([x_exp, y_exp], axis=2)
    shape = entry.shape
    entry = np.reshape(entry, [shape[0] * shape[1], 2])

    output = neuron.activate(entry)
    output = np.reshape(output, [shape[0], shape[1], 1])
    output = np.squeeze(output, axis=2)

    fig = plt.figure()
    ax = plt.axes(projection='3d')
    ax.plot_surface(x, y, output, rstride=1, cstride=1,
                    cmap='viridis', edgecolor='none')
    ax.set_title('Neuron activation');
    plt.show()

if __name__ == "__main__":
    # ------------------ Tune these parameters ---------------
    weights = np.array([[1.0, 1.0, 1.0]]) # The last number is the bias
    # --------------------------------------------------------

    neuron = Neuron(2, weights=weights)

    visualize_activation(neuron)
