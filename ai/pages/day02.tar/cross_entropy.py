import numpy as np
from Neuron import Neuron

def calculate_cross_entropy(entries, predictions, expected_outs):
    # <====== To complete | Exercice 4 ======>
    return 0.0

if __name__ == "__main__":
    weights = np.array([[2.3, -3.2, -1.42]])

    neuron = Neuron(2, weights=weights)

    entries = np.array([[1.0, -1.0], \
                        [-2.42, -2.42], \
                        [0.7, -0.3], \
                        [0.0, 0.1]])
    expected_outs = np.array([[0.0],
                              [1.0],
                              [0.0],
                              [1.0]])

    predictions = neuron.activate(entries)

    print(calculate_cross_entropy(entries, predictions, expected_outs))
